//Javascript-Ressource-Bundle - FRENCH

var rb = new Array(
"Product.",  // 0-LBL_ERTRAG
"Udc",     // 1-LBL_UDC
"kWp",     // 2-LBL_KWP
"Courbe de rendement",     // 3-LBL_ERTRAGSLINIE
"Tension d�entr&eacute;e", // 4-LBL_EINGANGSSPANNUNG
"Ordonn&eacute;es en <br>Puissance sp&eacute;cifique", // 5-LBL_SPEZLSTG
"�C",   // 6-LBL_GRADC 
"Temp. int&eacute;rieure<br>de l�onduleur",    // 7-LBL_ITEMP
"Toutes", // 8-LBL_ALLEWR
"Ond.",   // 9-LBL_WR ("WR=Wechselrichter")
"Puiss. du g&eacute;n&eacute;rateur",    // 10-LBL_GENLSTG
"Installation globale",  // 11-LBL_PRZT_GESLSTG
"Tous les onduleurs",  // 12-LBL_ALLEWR2
"Puiss. totale du g&eacute;n&eacute;rateur", // 13-LBL_GESLSTG
"Bilan quotidien",  // 14-LBL_TAGHEADER
"Bilan mensuel", // 15-LBL_MONATHEADER
"Bilan annuel", // 16-LBL_JAHRHEADER
"Bilan de toutes les ann&eacute;es", // 17-LBL_GESAMTHEADER
"Jour",  // 18-LBL_TAG
"Mois",    // 19-LBL_MONAT
"Ann&eacute;e", // 20-LBL_JAHR
"Total",   // 21-LBL_GESAMT
"Janvier","F&eacute;vrier","Mars","Avril","Mai","Juin","Juillet","Ao&ucirc;t","Septembre","Octobre","Novembre","D&eacute;cembre",
"Objectif journalier",    // 34-LBL_TAGESSOLL
"Pronostic",     // 35-LBL_PROGNOSE
"Vis&eacute;", // 36-LBL_SOLL
"Actuel", // 37-LBL_MOMENTAN
"Puissance d�entr&eacute;e Pac",    // 38-LBL_EINSPEISELSTG
"G&eacute;n&eacute;rateur",    // 39-LBL_GENERATOR
"Efficacit&eacute; de l�onduleur &eta;",    // 40-LBL_WG
"Rendement sp&eacute;cifique",    // 41-LBL_ERTRAG_SPEZ
"Statut",    // 42-LBL_STATUS
"Valeur max.",    // 43-LBL_MAXIMALWERT
"Erreur",    // 44-LBL_FEHLER
"Cumul",    // 45-LBL_AUFLAUFEND
"r&eacute;el", // 46-LBL_IST
"CO<sub>2</sub>&eacute;vit&eacute;-Emission totale", // 47-LBL_CO2
"Info installation", // 48-LBL_ANLAGENINFO
"Bilan total", // 49-LBL_GESAMTHEADER2
"Affichage PDA", // 50-LBL_PDA
"Rapport d�&eacute;v&eacute;nements", // 51-LBL_EREIGNIS
"Monitor&eacute; par", // 52-LBL_POWEREDBY
"Ev&eacute;nement de", // 53-LBL_EVENTVON
"Ev&eacute;nement jusqu�&agrave;", // 54-LBL_EVENTBIS
"Lieu", // 55-LBL_STANDORT
"Module", // 56-LBL_MODULE
"Onduleur", // 57-LBL_WECHSELRICHTER
"Puissance", // 58-LBL_LEISTUNG
"Mise en service", // 59-LBL_INBETRIEB
"Orientation", // 60-LBL_AUSRICHTUNG
"Surveillance de l�installation", // 61-LBL_ANLAGEN
"Op&eacute;rateur", // 62-LBL_BETRIEBER
"Jan,F&eacute;v,Mar,Avr,Mai,Juin,Juil,Aou,Sep,Oct,Nov,D&eacute;c,", // 63-LBL_MONKURZ
"Donn&eacute;es en ligne du", // 64-LBL_ONLINEVON
"Actuel", // 65-LBL_AKTUELL
"Aujourd�hui", // 66-LBL_HEUTE
"Eff.", // 67-LBL_WGKURZ
"sp&eacute;c.", // 68-LBL_SPEZ  (aus PALM: "Espez")
"Values", // 69-LBL_VISU_WERTE
"Show values", // 70-LBL_VISU_WERTE_ANZEIGEN
"Compare to past", // 71-LBL_VERGLEICHHEADER
"years", // 72-LBL_VERGLEICHHEADER_JAHRE
"Daily values:", // 73-LBL_VISU_TAGESWERTE
"Date", // 74-LBL_VISU_DATUM
"Yield total", // 75-LBL_TOP12_ERTRAG_ABSOLUT
"Yield specific", // 76-LBL_TOP12_ERTRAG_SPEZIFIFISCH
"Yield target", // 77-LBL_TOP12_ERTRAG_SOLL
"Yield/Target", // 78-LBL_VISU_ERTRAG_SOLL_IST
"Sum", //79-LBL_VISU_SUMME
"Monthly values:", // 80-LBL_VISU_MONATSWERTE
"Yearly values:", // 81-LBL_VISU_JAHRESWERTE
"S0 ", // 82-LBL_S0  //S0-IN
//"Alle Jahre<br>Liniendiagramm", // 83-LBL_VISU_GESAMT_LINIE
"Line overview years", // 83-LBL_VISU_GESAMT_LINIE
//"Alle Jahre<br>Balkendiagramm", // 84-LBL_VISU_GESAMT_BALKEN
"Chart overview years", // 84-LBL_VISU_GESAMT_BALKEN
"Trend in first year", // 85-LBL_VERLAUFHEADER
"Events starting - until", // 86-LBL_EVENT_VONBIS
"Hour", // 87-LBL_HOUR
"Rayonn.", // 88-LBL_IRR ("Solar-Irradiation)
"T�mod.", // 89-LBL_MODULTEMP
"T�amb.", // 90-AMBTEMP
"Vent", // 91-WIND
"Capteur de rayonnement", // 92-LBL_IRR2 ("Solar-Irradiation)
"Temp&eacute;rature du module", // 93-LBL_MODULTEMP2
"Temp&eacute;rature ambiante", // 94-AMBTEMP2
"Vitesse du vent", // 95-WIND2
"Aper&ccedil;u de la cha&icirc;ne", // 96-LBL_STRINGHEADER
"Bilan ", //97-LBL_FLAG_EEG
"Bilan &eacute;nerg&eacute;tique avec consommation propre", // 98-LBL_FLAG_EEG_BEZ
"Bilan &eacute;nerg&eacute;tique avec d&eacute;termination de la consommation propre", // 99-LBL_EEG_BILANZ
"Quote-part de consommation propre", // 100-LBL_EEG_QUOTE
"Tous", // 101-LBL_ALLE
"Jours ", // 102-LBL_TAGE
"Groupes d'installations", // 103-LBL_GRUPPEN
"Statut", // 104-LBL_STATI
"Groupe d'installation", // 105-LBL_ANLAGENGRP
"Ev&eacute;nement de - &agrave;", // 106-LBL_EVENT_VONBIS
"Annuler la s&eacute;lection", // 107-LBL_CLEARLIST
" davantage de lignes, non affich&eacute;es pour des raisons de compatibilit&eacute; de navigateur", // 108-LBL_MOREROWS
"Consommation  tot.", // 109-LBL_VERBRAUCH_GES
"produit simultan&eacute;ment", // 110-LBL_Z_ERZEUGT
"Affichage 24 heures", // 111-LBL_24H_SCALE
"Rendement non disponible", // 112-LBL_NO_DATA
"")

var LBL_NO_DATA = 112;
var LBL_24H_SCALE = 111;
var LBL_Z_ERZEUGT = 110;
var LBL_VERBRAUCH_GES = 109;
var LBL_MOREROWS = 108;
var LBL_CLEARLIST = 107;
var LBL_EVENT_VONBIS = 106;
var LBL_ANLAGENGRP = 105;
var LBL_STATI = 104;
var LBL_GRUPPEN = 103;
var LBL_TAGE = 102;
var LBL_ALLE = 101;

var LBL_EEG_QUOTE = 100;
var LBL_EEG_BILANZ = 99;
var LBL_FLAG_EEG_BEZ = 98;
var LBL_FLAG_EEG = 97;
var LBL_STRINGHEADER = 96;
var LBL_WIND2 = 95
var LBL_AMBTEMP2 = 94
var LBL_MODULTEMP2 = 93
var LBL_IRR2 = 92
var LBL_WIND = 91
var LBL_AMBTEMP = 90
var LBL_MODULTEMP = 89
var LBL_IRR = 88
var LBL_HOUR = 87
var LBL_EVENT_VONBIS = 86
var LBL_VERLAUFHEADER = 85
var LBL_VISU_GESAMT_BALKEN = 84
var LBL_VISU_GESAMT_LINIE = 83
var LBL_S0 = 82
var LBL_VISU_JAHRESWERTE = 81
var LBL_VISU_MONATSWERTE = 80
var LBL_VISU_SUMME = 79
var LBL_VISU_ERTRAG_SOLL_IST = 78
var LBL_TOP12_ERTRAG_SOLL = 77
var LBL_TOP12_ERTRAG_SPEZIFISCH = 76
var LBL_TOP12_ERTRAG_ABSOLUT = 75
var LBL_VISU_DATUM = 74
var LBL_VISU_TAGESWERTE = 73
var LBL_VERGLEICHHEADER_JAHRE = 72
var LBL_VERGLEICHHEADER = 71
var LBL_VISU_WERTE_ANZEIGEN = 70
var LBL_VISU_WERTE = 69
var LBL_SPEZ = 68
var LBL_WGKURZ = 67
var LBL_HEUTE = 66
var LBL_AKTUELL = 65
var LBL_ONLINEVON = 64
var LBL_MONKURZ = 63
var LBL_BETRIEBER = 62
var LBL_ANLAGEN = 61
var LBL_AUSRICHTUNG = 60
var LBL_INBETRIEB = 59
var LBL_LEISTUNG = 58
var LBL_WECHSELRICHTER = 57
var LBL_MODULE = 56
var LBL_STANDORT = 55
var LBL_EVENTBIS = 54
var LBL_EVENTVON = 53
var LBL_POWEREDBY = 52
var LBL_EREIGNIS = 51
var LBL_PDA = 50
var LBL_GESAMTHEADER2 = 49
var LBL_ANLAGENINFO = 48
var LBL_CO2 = 47
var LBL_IST = 46
var LBL_AUFLAUFEND = 45
var LBL_FEHLER = 44
var LBL_MAXIMALWERT = 43
var LBL_STATUS = 42
var LBL_ERTRAG_SPEZ = 41
var LBL_WG = 40
var LBL_GENERATOR = 39
var LBL_EINSPEISELSTG = 38
var LBL_MOMENTAN = 37

var LBL_ERTRAG  =0
var LBL_UDC     =1
var LBL_KWP     =2
var LBL_ERTRAGSLINIE     =3
var LBL_EINGANGSSPANNUNG   =4
var LBL_SPEZLSTG     =5
var LBL_GRADC     =6
var LBL_ITEMP     =7
var LBL_ALLEWR     =8
var LBL_WR     =9
var LBL_GENLSTG     =10
var LBL_PRZT_GESLSTG     =11
var LBL_ALLEWR2     =12
var LBL_GESLSTG     =13
var LBL_TAGHEADER     =14
var LBL_MONATHEADER     =15
var LBL_JAHRHEADER     =16
var LBL_GESAMTHEADER     =17
var LBL_TAG     =18
var LBL_MONAT     =19
var LBL_JAHR     =20
var LBL_GESAMT     =21
var LBL_MON01 = 22
var LBL_MON02 = 23
var LBL_MON03 = 24
var LBL_MON04 = 25
var LBL_MON05 = 26
var LBL_MON06 = 27
var LBL_MON07 = 28
var LBL_MON08 = 29
var LBL_MON09 = 30
var LBL_MON10 = 31
var LBL_MON11 = 32
var LBL_MON12 = 33
var LBL_TAGESSOLL = 34
var LBL_PROGNOSE = 35
var LBL_SOLL = 36

//***********************************
function getText(index) {
return rb[index]
}
