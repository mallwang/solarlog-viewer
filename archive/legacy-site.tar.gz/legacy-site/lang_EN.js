//Javascript-Ressource-Bundle - ENGLISH

var rb = new Array(
"yield",  // 0-LBL_ERTRAG
"Udc",     // 1-LBL_UDC
"kWp",     // 2-LBL_KWP
"yield curve",     // 3-LBL_ERTRAGSLINIE
"input voltage", // 4-LBL_EINGANGSSPANNUNG
"Y-scale in<br>specific power", // 5-LBL_SPEZLSTG
"�C",   // 6-LBL_GRADC
"temperature<br>inside inverter",    // 7-LBL_ITEMP
"ALL", // 8-LBL_ALLEWR
"INV",   // 9-LBL_WR ("WR=Wechselrichter")
"generator power",    // 10-LBL_GENLSTG
"from total system",  // 11-LBL_PRZT_GESLSTG
"all inverter",  // 12-LBL_ALLEWR2
"total generator power", // 13-LBL_GESLSTG
"overview daily",  // 14-LBL_TAGHEADER
"overview monthly", // 15-LBL_MONATHEADER
"overview yearly", // 16-LBL_JAHRHEADER
"overview all years", // 17-LBL_GESAMTHEADER
"day",  // 18-LBL_TAG
"month",    // 19-LBL_MONAT
"year", // 20-LBL_JAHR
"total",   // 21-LBL_GESAMT
"January","February","March","April","May","June","July","August","September","October","November","December",
"daily set value",    // 34-LBL_TAGESSOLL
"forecast",     // 35-LBL_PROGNOSE
"set value", // 36-LBL_SOLL
"current", // 37-LBL_MOMENTAN
"feeding power Pac",    // 38-LBL_EINSPEISELSTG
"generator",    // 39-LBL_GENERATOR
"inverter efficiency &eta;",    // 40-LBL_WG
"specific yield",    // 41-LBL_ERTRAG_SPEZ
"status",    // 42-LBL_STATUS
"maximum value",    // 43-LBL_MAXIMALWERT
"error",    // 44-LBL_FEHLER
"cumulative",    // 45-LBL_AUFLAUFEND
"actual", // 46-LBL_IST
"avoided CO<sub>2</sub>-emission total", // 47-LBL_CO2
"info system", // 48-LBL_ANLAGENINFO
"overview total", // 49-LBL_GESAMTHEADER2
"PDA view", // 50-LBL_PDA
"event log", // 51-LBL_EREIGNIS
"supervised by", // 52-LBL_POWEREDBY
"event from", // 53-LBL_EVENTVON
"event to", // 54-LBL_EVENTBIS
"location", // 55-LBL_STANDORT
"modules", // 56-LBL_MODULE
"inverter", // 57-LBL_WECHSELRICHTER
"installed power", // 58-LBL_LEISTUNG
"start of operation", // 59-LBL_INBETRIEB
"orientation", // 60-LBL_AUSRICHTUNG
"system supervision", // 61-LBL_ANLAGEN
"system operator", // 62-LBL_BETRIEBER
"jan,fab,mar,apr,may,jun,jul,aug,sep,oct,nov,dec,", // 63-LBL_MONKURZ
"online data from", // 64-LBL_ONLINEVON
"current", // 65-LBL_AKTUELL
"today", // 66-LBL_HEUTE
"INV &eta;", // 67-LBL_WGKURZ
"spec", // 68-LBL_SPEZ  (aus PALM: "Espez")
"Values", // 69-LBL_VISU_WERTE
"Show values", // 70-LBL_VISU_WERTE_ANZEIGEN
"Compare to past", // 71-LBL_VERGLEICHHEADER
"years", // 72-LBL_VERGLEICHHEADER_JAHRE
"Daily values:", // 73-LBL_VISU_TAGESWERTE
"Date", // 74-LBL_VISU_DATUM
"Yield total", // 75-LBL_TOP12_ERTRAG_ABSOLUT
"Yield specific", // 76-LBL_TOP12_ERTRAG_SPEZIFIFISCH
"Yield target", // 77-LBL_TOP12_ERTRAG_SOLL
"Yield/Target", // 78-LBL_VISU_ERTRAG_SOLL_IST
"Sum", //79-LBL_VISU_SUMME
"Monthly values:", // 80-LBL_VISU_MONATSWERTE
"Yearly values:", // 81-LBL_VISU_JAHRESWERTE
"S0 ", // 82-LBL_S0  //S0-IN
//"Alle Jahre<br>Liniendiagramm", // 83-LBL_VISU_GESAMT_LINIE
"Line overview years", // 83-LBL_VISU_GESAMT_LINIE
//"Alle Jahre<br>Balkendiagramm", // 84-LBL_VISU_GESAMT_BALKEN
"Chart overview years", // 84-LBL_VISU_GESAMT_BALKEN
"Trend in first year", // 85-LBL_VERLAUFHEADER
"Events starting - until", // 86-LBL_EVENT_VONBIS
"Hour", // 87-LBL_HOUR
"Solar", // 88-LBL_IRR ("Solar-Irradiation)
"Mod-T", // 89-LBL_MODULTEMP
"Env-T", // 90-AMBTEMP
"Wind", // 91-WIND
"Solar irradiation sensor", // 92-LBL_IRR2 ("Solar-Irradiation)
"Module temperature", // 93-LBL_MODULTEMP2
"Outside temperature", // 94-AMBTEMP2
"Wind speed", // 95-WIND2
"String overview", // 96-LBL_STRINGHEADER
"Balance", //97-LBL_FLAG_EEG
"Energy balance with own consumption", // 98-LBL_FLAG_EEG_BEZ
"Energy balance with own consumption calculation", // 99-LBL_EEG_BILANZ
"Own consumption rate", // 100-LBL_EEG_QUOTE
"All", // 101-LBL_ALLE
"days", // 102-LBL_TAGE
"Plant groups", // 103-LBL_GRUPPEN
"Status", // 104-LBL_STATI
"Plant group", // 105-LBL_ANLAGENGRP
"Event from - until", // 106-LBL_EVENT_VONBIS
"Reset selection", // 107-LBL_CLEARLIST
" additional lines available, but too many data", // 108-LBL_MOREROWS
"Total consumption.", // 109-LBL_VERBRAUCH_GES
"Produced at same time", // 110-LBL_Z_ERZEUGT
"24-hour-scale", // 111-LBL_24H_SCALE
"No data available", // 112-LBL_NO_DATA
"")

var LBL_NO_DATA = 112;
var LBL_24H_SCALE = 111;
var LBL_Z_ERZEUGT = 110;
var LBL_VERBRAUCH_GES = 109;
var LBL_MOREROWS = 108;
var LBL_CLEARLIST = 107;
var LBL_EVENT_VONBIS = 106;
var LBL_ANLAGENGRP = 105;
var LBL_STATI = 104;
var LBL_GRUPPEN = 103;
var LBL_TAGE = 102;
var LBL_ALLE = 101;

var LBL_EEG_QUOTE = 100;
var LBL_EEG_BILANZ = 99;
var LBL_FLAG_EEG_BEZ = 98;
var LBL_FLAG_EEG = 97;
var LBL_STRINGHEADER = 96;
var LBL_WIND2 = 95
var LBL_AMBTEMP2 = 94
var LBL_MODULTEMP2 = 93
var LBL_IRR2 = 92
var LBL_WIND = 91
var LBL_AMBTEMP = 90
var LBL_MODULTEMP = 89
var LBL_IRR = 88
var LBL_HOUR = 87
var LBL_EVENT_VONBIS = 86
var LBL_VERLAUFHEADER = 85
var LBL_VISU_GESAMT_BALKEN = 84
var LBL_VISU_GESAMT_LINIE = 83
var LBL_S0 = 82
var LBL_VISU_JAHRESWERTE = 81
var LBL_VISU_MONATSWERTE = 80
var LBL_VISU_SUMME = 79
var LBL_VISU_ERTRAG_SOLL_IST = 78
var LBL_TOP12_ERTRAG_SOLL = 77
var LBL_TOP12_ERTRAG_SPEZIFISCH = 76
var LBL_TOP12_ERTRAG_ABSOLUT = 75
var LBL_VISU_DATUM = 74
var LBL_VISU_TAGESWERTE = 73
var LBL_VERGLEICHHEADER_JAHRE = 72
var LBL_VERGLEICHHEADER = 71
var LBL_VISU_WERTE_ANZEIGEN = 70
var LBL_VISU_WERTE = 69
var LBL_SPEZ = 68
var LBL_WGKURZ = 67
var LBL_HEUTE = 66
var LBL_AKTUELL = 65
var LBL_ONLINEVON = 64
var LBL_MONKURZ = 63
var LBL_BETRIEBER = 62
var LBL_ANLAGEN = 61
var LBL_AUSRICHTUNG = 60
var LBL_INBETRIEB = 59
var LBL_LEISTUNG = 58
var LBL_WECHSELRICHTER = 57
var LBL_MODULE = 56
var LBL_STANDORT = 55
var LBL_EVENTBIS = 54
var LBL_EVENTVON = 53
var LBL_POWEREDBY = 52
var LBL_EREIGNIS = 51
var LBL_PDA = 50
var LBL_GESAMTHEADER2 = 49
var LBL_ANLAGENINFO = 48
var LBL_CO2 = 47
var LBL_IST = 46
var LBL_AUFLAUFEND = 45
var LBL_FEHLER = 44
var LBL_MAXIMALWERT = 43
var LBL_STATUS = 42
var LBL_ERTRAG_SPEZ = 41
var LBL_WG = 40
var LBL_GENERATOR = 39
var LBL_EINSPEISELSTG = 38
var LBL_MOMENTAN = 37

var LBL_ERTRAG  =0
var LBL_UDC     =1
var LBL_KWP     =2
var LBL_ERTRAGSLINIE     =3
var LBL_EINGANGSSPANNUNG   =4
var LBL_SPEZLSTG     =5
var LBL_GRADC     =6
var LBL_ITEMP     =7
var LBL_ALLEWR     =8
var LBL_WR     =9
var LBL_GENLSTG     =10
var LBL_PRZT_GESLSTG     =11
var LBL_ALLEWR2     =12
var LBL_GESLSTG     =13
var LBL_TAGHEADER     =14
var LBL_MONATHEADER     =15
var LBL_JAHRHEADER     =16
var LBL_GESAMTHEADER     =17
var LBL_TAG     =18
var LBL_MONAT     =19
var LBL_JAHR     =20
var LBL_GESAMT     =21
var LBL_MON01 = 22
var LBL_MON02 = 23
var LBL_MON03 = 24
var LBL_MON04 = 25
var LBL_MON05 = 26
var LBL_MON06 = 27
var LBL_MON07 = 28
var LBL_MON08 = 29
var LBL_MON09 = 30
var LBL_MON10 = 31
var LBL_MON11 = 32
var LBL_MON12 = 33
var LBL_TAGESSOLL = 34
var LBL_PROGNOSE = 35
var LBL_SOLL = 36

//***********************************
function getText(index) {
return rb[index]
}
